                        #FAANG
# 1.This is a sample app.
# 2.This app is only for fAANG employees.
import os

print("Please log in")
# emid = ['sunderpichai@gmail.com', 'mark@gmail.com', 'zeff@gmail.com', 'steve@gmail.com']
n_ame = input("Enter your name: ")
id_pwd = input("Enter your id password: ")
print(f"A file FAANG id pwd has been created in your device that contains your id password {id_pwd}")
with open('FAANG id pwd.txt', 'w') as f:
    f.write(id_pwd)
em_id = input("Enter your email id: ")
if 'sunderpichai@gmail.com' or 'mark@gmail.com'or 'zeff@gmail.com'or 'steve@gmail.com' in em_id:
    print("Welcome")
if 'sunderpichai@gmail.com' or 'mark@gmail.com'or 'zeff@gmail.com'or 'steve@gmail.com'  not in em_id:
    print("")

company = input("Enter your company's name: ")
vc_names = ['Facebook', 'Apple', 'Amazon', 'Netflix', 'Google', 'Meta']
if 'Facebook' or 'Google' or 'Apple' or 'Meta' or 'Amazon' or 'Netflix' in (company):
    print("Welcome!")
else: 
    print ("Sorry this app is only for FAANG employees.")
     
print(f"Welcome {n_ame}!, your account has been created.")     